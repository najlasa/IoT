<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rfid extends CI_Controller {


	public function index()
	{
		echo "Index RFID.php";
	}

	public function insert(){
		$this->load->model('m_belajar');
		if (isset($_GET['id_device']) && isset($_GET['rfid'])) {
			//echo "OK";
			$id_device = $this->input->get('id_device');
			$rfid = $this->input->get('rfid');

			$dataRfid = array('id_device' => $id_device, 'uid_rfid' => $rfid, 'waktu' => time());

			if($this->m_belajar->saveRfid($dataRfid)){
				echo "BERHASIL";
			}else{
				echo "ERROR";
			}
		}else{
			echo "Variabel data tidak terdefinisi";
		}
	}

	public function show(){
		date_default_timezone_set("Asia/Jakarta");
		$this->load->model('m_belajar');

		$data['rfid'] = $this->m_belajar->ambildataRfid();

		$this->load->view('view_rfid', $data);
	}
}
