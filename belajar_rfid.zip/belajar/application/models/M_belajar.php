<?php
/**
* 
*/
class M_belajar extends CI_Model
{
	
	function save($datasensor)
	{
		$this->db->insert('sensor', $datasensor);
		return TRUE;
	}

	function ambildata(){
		$this->db->select('*');
		$this->db->from('sensor');
		$query = $this->db->get();
		if ($query->num_rows()>0) {
			return $query->result();
		}
	}

	function ambildataperintah(){
		$this->db->select('*');
		$this->db->from('perintah');
		$this->db->where('id_perintah',1);
		$query = $this->db->get();
		if ($query->num_rows()>0) {
			return $query->result();
		}
	}

	function saveRfid($data){
		$this->db->insert('rfid', $data);
		return TRUE;
	}

	function ambildataRfid(){
		$this->db->select('*');
		$this->db->from('rfid');
		$this->db->order_by('id_data','DESC');
		$query = $this->db->get();
		if ($query->num_rows()>0) {
			return $query->result();
		}
	}
}

?>