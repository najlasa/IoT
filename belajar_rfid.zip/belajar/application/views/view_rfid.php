<?php
// foreach ($rfid as $key => $value) {
// 	echo $value->uid_rfid;
// 	echo "<br>";
// }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Table RFID</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="http://localhost/belajar/vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="http://localhost/belajar/css/util.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/belajar/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100">
					<table>
						<thead>
							<tr class="table100-head">
								<th class="column1">No</th>
								<th class="column2">ID Data</th>
								<th class="column3">ID Device</th>
								<th class="column3">UID RFID</th>
								<th class="column4">Waktu</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$no = 0;
						if (isset($rfid)) {
							foreach ($rfid as $key => $value) {
							$no++;
						?>
								<tr>
									<td class="column1"><?=$no;?></td>
									<td class="column2"><?=$value->id_data;?></td>
									<td class="column2"><?=$value->id_device;?></td>
									<td class="column3"><?=$value->uid_rfid;?></td>
									<td class="column4"><?=date("d-M-Y H:i:s",$value->waktu);?></td>
								</tr>	
						<?php
							}
						}
						?>							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="http://localhost/belajar/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="http://localhost/belajar/js/main.js"></script>

</body>
</html>